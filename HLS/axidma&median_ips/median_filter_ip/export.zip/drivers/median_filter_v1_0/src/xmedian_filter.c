// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2022.2 (64-bit)
// Tool Version Limit: 2019.12
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// ==============================================================
/***************************** Include Files *********************************/
#include "xmedian_filter.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XMedian_filter_CfgInitialize(XMedian_filter *InstancePtr, XMedian_filter_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Control_BaseAddress = ConfigPtr->Control_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XMedian_filter_Start(XMedian_filter *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XMedian_filter_ReadReg(InstancePtr->Control_BaseAddress, XMEDIAN_FILTER_CONTROL_ADDR_AP_CTRL) & 0x80;
    XMedian_filter_WriteReg(InstancePtr->Control_BaseAddress, XMEDIAN_FILTER_CONTROL_ADDR_AP_CTRL, Data | 0x01);
}

u32 XMedian_filter_IsDone(XMedian_filter *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XMedian_filter_ReadReg(InstancePtr->Control_BaseAddress, XMEDIAN_FILTER_CONTROL_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XMedian_filter_IsIdle(XMedian_filter *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XMedian_filter_ReadReg(InstancePtr->Control_BaseAddress, XMEDIAN_FILTER_CONTROL_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XMedian_filter_IsReady(XMedian_filter *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XMedian_filter_ReadReg(InstancePtr->Control_BaseAddress, XMEDIAN_FILTER_CONTROL_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XMedian_filter_EnableAutoRestart(XMedian_filter *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMedian_filter_WriteReg(InstancePtr->Control_BaseAddress, XMEDIAN_FILTER_CONTROL_ADDR_AP_CTRL, 0x80);
}

void XMedian_filter_DisableAutoRestart(XMedian_filter *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMedian_filter_WriteReg(InstancePtr->Control_BaseAddress, XMEDIAN_FILTER_CONTROL_ADDR_AP_CTRL, 0);
}

void XMedian_filter_Set_length_r(XMedian_filter *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMedian_filter_WriteReg(InstancePtr->Control_BaseAddress, XMEDIAN_FILTER_CONTROL_ADDR_LENGTH_R_DATA, Data);
}

u32 XMedian_filter_Get_length_r(XMedian_filter *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XMedian_filter_ReadReg(InstancePtr->Control_BaseAddress, XMEDIAN_FILTER_CONTROL_ADDR_LENGTH_R_DATA);
    return Data;
}

void XMedian_filter_Set_width(XMedian_filter *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMedian_filter_WriteReg(InstancePtr->Control_BaseAddress, XMEDIAN_FILTER_CONTROL_ADDR_WIDTH_DATA, Data);
}

u32 XMedian_filter_Get_width(XMedian_filter *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XMedian_filter_ReadReg(InstancePtr->Control_BaseAddress, XMEDIAN_FILTER_CONTROL_ADDR_WIDTH_DATA);
    return Data;
}

void XMedian_filter_InterruptGlobalEnable(XMedian_filter *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMedian_filter_WriteReg(InstancePtr->Control_BaseAddress, XMEDIAN_FILTER_CONTROL_ADDR_GIE, 1);
}

void XMedian_filter_InterruptGlobalDisable(XMedian_filter *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMedian_filter_WriteReg(InstancePtr->Control_BaseAddress, XMEDIAN_FILTER_CONTROL_ADDR_GIE, 0);
}

void XMedian_filter_InterruptEnable(XMedian_filter *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XMedian_filter_ReadReg(InstancePtr->Control_BaseAddress, XMEDIAN_FILTER_CONTROL_ADDR_IER);
    XMedian_filter_WriteReg(InstancePtr->Control_BaseAddress, XMEDIAN_FILTER_CONTROL_ADDR_IER, Register | Mask);
}

void XMedian_filter_InterruptDisable(XMedian_filter *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XMedian_filter_ReadReg(InstancePtr->Control_BaseAddress, XMEDIAN_FILTER_CONTROL_ADDR_IER);
    XMedian_filter_WriteReg(InstancePtr->Control_BaseAddress, XMEDIAN_FILTER_CONTROL_ADDR_IER, Register & (~Mask));
}

void XMedian_filter_InterruptClear(XMedian_filter *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMedian_filter_WriteReg(InstancePtr->Control_BaseAddress, XMEDIAN_FILTER_CONTROL_ADDR_ISR, Mask);
}

u32 XMedian_filter_InterruptGetEnabled(XMedian_filter *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XMedian_filter_ReadReg(InstancePtr->Control_BaseAddress, XMEDIAN_FILTER_CONTROL_ADDR_IER);
}

u32 XMedian_filter_InterruptGetStatus(XMedian_filter *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XMedian_filter_ReadReg(InstancePtr->Control_BaseAddress, XMEDIAN_FILTER_CONTROL_ADDR_ISR);
}

