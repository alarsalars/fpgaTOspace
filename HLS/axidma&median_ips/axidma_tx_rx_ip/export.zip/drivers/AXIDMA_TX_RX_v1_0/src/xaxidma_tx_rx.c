// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2022.2 (64-bit)
// Tool Version Limit: 2019.12
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// ==============================================================
/***************************** Include Files *********************************/
#include "xaxidma_tx_rx.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XAxidma_tx_rx_CfgInitialize(XAxidma_tx_rx *InstancePtr, XAxidma_tx_rx_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Control_BaseAddress = ConfigPtr->Control_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XAxidma_tx_rx_Start(XAxidma_tx_rx *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XAxidma_tx_rx_ReadReg(InstancePtr->Control_BaseAddress, XAXIDMA_TX_RX_CONTROL_ADDR_AP_CTRL) & 0x80;
    XAxidma_tx_rx_WriteReg(InstancePtr->Control_BaseAddress, XAXIDMA_TX_RX_CONTROL_ADDR_AP_CTRL, Data | 0x01);
}

u32 XAxidma_tx_rx_IsDone(XAxidma_tx_rx *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XAxidma_tx_rx_ReadReg(InstancePtr->Control_BaseAddress, XAXIDMA_TX_RX_CONTROL_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XAxidma_tx_rx_IsIdle(XAxidma_tx_rx *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XAxidma_tx_rx_ReadReg(InstancePtr->Control_BaseAddress, XAXIDMA_TX_RX_CONTROL_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XAxidma_tx_rx_IsReady(XAxidma_tx_rx *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XAxidma_tx_rx_ReadReg(InstancePtr->Control_BaseAddress, XAXIDMA_TX_RX_CONTROL_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XAxidma_tx_rx_EnableAutoRestart(XAxidma_tx_rx *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XAxidma_tx_rx_WriteReg(InstancePtr->Control_BaseAddress, XAXIDMA_TX_RX_CONTROL_ADDR_AP_CTRL, 0x80);
}

void XAxidma_tx_rx_DisableAutoRestart(XAxidma_tx_rx *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XAxidma_tx_rx_WriteReg(InstancePtr->Control_BaseAddress, XAXIDMA_TX_RX_CONTROL_ADDR_AP_CTRL, 0);
}

void XAxidma_tx_rx_Set_axi_burst_in(XAxidma_tx_rx *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XAxidma_tx_rx_WriteReg(InstancePtr->Control_BaseAddress, XAXIDMA_TX_RX_CONTROL_ADDR_AXI_BURST_IN_DATA, (u32)(Data));
    XAxidma_tx_rx_WriteReg(InstancePtr->Control_BaseAddress, XAXIDMA_TX_RX_CONTROL_ADDR_AXI_BURST_IN_DATA + 4, (u32)(Data >> 32));
}

u64 XAxidma_tx_rx_Get_axi_burst_in(XAxidma_tx_rx *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XAxidma_tx_rx_ReadReg(InstancePtr->Control_BaseAddress, XAXIDMA_TX_RX_CONTROL_ADDR_AXI_BURST_IN_DATA);
    Data += (u64)XAxidma_tx_rx_ReadReg(InstancePtr->Control_BaseAddress, XAXIDMA_TX_RX_CONTROL_ADDR_AXI_BURST_IN_DATA + 4) << 32;
    return Data;
}

void XAxidma_tx_rx_Set_axi_burst_out(XAxidma_tx_rx *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XAxidma_tx_rx_WriteReg(InstancePtr->Control_BaseAddress, XAXIDMA_TX_RX_CONTROL_ADDR_AXI_BURST_OUT_DATA, (u32)(Data));
    XAxidma_tx_rx_WriteReg(InstancePtr->Control_BaseAddress, XAXIDMA_TX_RX_CONTROL_ADDR_AXI_BURST_OUT_DATA + 4, (u32)(Data >> 32));
}

u64 XAxidma_tx_rx_Get_axi_burst_out(XAxidma_tx_rx *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XAxidma_tx_rx_ReadReg(InstancePtr->Control_BaseAddress, XAXIDMA_TX_RX_CONTROL_ADDR_AXI_BURST_OUT_DATA);
    Data += (u64)XAxidma_tx_rx_ReadReg(InstancePtr->Control_BaseAddress, XAXIDMA_TX_RX_CONTROL_ADDR_AXI_BURST_OUT_DATA + 4) << 32;
    return Data;
}

void XAxidma_tx_rx_Set_length_r(XAxidma_tx_rx *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XAxidma_tx_rx_WriteReg(InstancePtr->Control_BaseAddress, XAXIDMA_TX_RX_CONTROL_ADDR_LENGTH_R_DATA, Data);
}

u32 XAxidma_tx_rx_Get_length_r(XAxidma_tx_rx *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XAxidma_tx_rx_ReadReg(InstancePtr->Control_BaseAddress, XAXIDMA_TX_RX_CONTROL_ADDR_LENGTH_R_DATA);
    return Data;
}

void XAxidma_tx_rx_Set_width(XAxidma_tx_rx *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XAxidma_tx_rx_WriteReg(InstancePtr->Control_BaseAddress, XAXIDMA_TX_RX_CONTROL_ADDR_WIDTH_DATA, Data);
}

u32 XAxidma_tx_rx_Get_width(XAxidma_tx_rx *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XAxidma_tx_rx_ReadReg(InstancePtr->Control_BaseAddress, XAXIDMA_TX_RX_CONTROL_ADDR_WIDTH_DATA);
    return Data;
}

void XAxidma_tx_rx_InterruptGlobalEnable(XAxidma_tx_rx *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XAxidma_tx_rx_WriteReg(InstancePtr->Control_BaseAddress, XAXIDMA_TX_RX_CONTROL_ADDR_GIE, 1);
}

void XAxidma_tx_rx_InterruptGlobalDisable(XAxidma_tx_rx *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XAxidma_tx_rx_WriteReg(InstancePtr->Control_BaseAddress, XAXIDMA_TX_RX_CONTROL_ADDR_GIE, 0);
}

void XAxidma_tx_rx_InterruptEnable(XAxidma_tx_rx *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XAxidma_tx_rx_ReadReg(InstancePtr->Control_BaseAddress, XAXIDMA_TX_RX_CONTROL_ADDR_IER);
    XAxidma_tx_rx_WriteReg(InstancePtr->Control_BaseAddress, XAXIDMA_TX_RX_CONTROL_ADDR_IER, Register | Mask);
}

void XAxidma_tx_rx_InterruptDisable(XAxidma_tx_rx *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XAxidma_tx_rx_ReadReg(InstancePtr->Control_BaseAddress, XAXIDMA_TX_RX_CONTROL_ADDR_IER);
    XAxidma_tx_rx_WriteReg(InstancePtr->Control_BaseAddress, XAXIDMA_TX_RX_CONTROL_ADDR_IER, Register & (~Mask));
}

void XAxidma_tx_rx_InterruptClear(XAxidma_tx_rx *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XAxidma_tx_rx_WriteReg(InstancePtr->Control_BaseAddress, XAXIDMA_TX_RX_CONTROL_ADDR_ISR, Mask);
}

u32 XAxidma_tx_rx_InterruptGetEnabled(XAxidma_tx_rx *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XAxidma_tx_rx_ReadReg(InstancePtr->Control_BaseAddress, XAXIDMA_TX_RX_CONTROL_ADDR_IER);
}

u32 XAxidma_tx_rx_InterruptGetStatus(XAxidma_tx_rx *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XAxidma_tx_rx_ReadReg(InstancePtr->Control_BaseAddress, XAXIDMA_TX_RX_CONTROL_ADDR_ISR);
}

