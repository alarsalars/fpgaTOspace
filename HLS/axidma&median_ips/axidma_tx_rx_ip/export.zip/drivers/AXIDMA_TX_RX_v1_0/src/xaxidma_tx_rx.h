// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2022.2 (64-bit)
// Tool Version Limit: 2019.12
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef XAXIDMA_TX_RX_H
#define XAXIDMA_TX_RX_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xaxidma_tx_rx_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
#else
typedef struct {
    u16 DeviceId;
    u64 Control_BaseAddress;
} XAxidma_tx_rx_Config;
#endif

typedef struct {
    u64 Control_BaseAddress;
    u32 IsReady;
} XAxidma_tx_rx;

typedef u32 word_type;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XAxidma_tx_rx_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XAxidma_tx_rx_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XAxidma_tx_rx_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XAxidma_tx_rx_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
int XAxidma_tx_rx_Initialize(XAxidma_tx_rx *InstancePtr, u16 DeviceId);
XAxidma_tx_rx_Config* XAxidma_tx_rx_LookupConfig(u16 DeviceId);
int XAxidma_tx_rx_CfgInitialize(XAxidma_tx_rx *InstancePtr, XAxidma_tx_rx_Config *ConfigPtr);
#else
int XAxidma_tx_rx_Initialize(XAxidma_tx_rx *InstancePtr, const char* InstanceName);
int XAxidma_tx_rx_Release(XAxidma_tx_rx *InstancePtr);
#endif

void XAxidma_tx_rx_Start(XAxidma_tx_rx *InstancePtr);
u32 XAxidma_tx_rx_IsDone(XAxidma_tx_rx *InstancePtr);
u32 XAxidma_tx_rx_IsIdle(XAxidma_tx_rx *InstancePtr);
u32 XAxidma_tx_rx_IsReady(XAxidma_tx_rx *InstancePtr);
void XAxidma_tx_rx_EnableAutoRestart(XAxidma_tx_rx *InstancePtr);
void XAxidma_tx_rx_DisableAutoRestart(XAxidma_tx_rx *InstancePtr);

void XAxidma_tx_rx_Set_axi_burst_in(XAxidma_tx_rx *InstancePtr, u64 Data);
u64 XAxidma_tx_rx_Get_axi_burst_in(XAxidma_tx_rx *InstancePtr);
void XAxidma_tx_rx_Set_axi_burst_out(XAxidma_tx_rx *InstancePtr, u64 Data);
u64 XAxidma_tx_rx_Get_axi_burst_out(XAxidma_tx_rx *InstancePtr);
void XAxidma_tx_rx_Set_length_r(XAxidma_tx_rx *InstancePtr, u32 Data);
u32 XAxidma_tx_rx_Get_length_r(XAxidma_tx_rx *InstancePtr);
void XAxidma_tx_rx_Set_width(XAxidma_tx_rx *InstancePtr, u32 Data);
u32 XAxidma_tx_rx_Get_width(XAxidma_tx_rx *InstancePtr);

void XAxidma_tx_rx_InterruptGlobalEnable(XAxidma_tx_rx *InstancePtr);
void XAxidma_tx_rx_InterruptGlobalDisable(XAxidma_tx_rx *InstancePtr);
void XAxidma_tx_rx_InterruptEnable(XAxidma_tx_rx *InstancePtr, u32 Mask);
void XAxidma_tx_rx_InterruptDisable(XAxidma_tx_rx *InstancePtr, u32 Mask);
void XAxidma_tx_rx_InterruptClear(XAxidma_tx_rx *InstancePtr, u32 Mask);
u32 XAxidma_tx_rx_InterruptGetEnabled(XAxidma_tx_rx *InstancePtr);
u32 XAxidma_tx_rx_InterruptGetStatus(XAxidma_tx_rx *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
