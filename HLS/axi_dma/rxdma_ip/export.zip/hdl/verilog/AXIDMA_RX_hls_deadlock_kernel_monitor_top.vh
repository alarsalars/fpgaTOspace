
wire kernel_monitor_reset;
wire kernel_monitor_clock;
wire kernel_monitor_report;
assign kernel_monitor_reset = ~ap_rst_n;
assign kernel_monitor_clock = ap_clk;
assign kernel_monitor_report = 1'b0;
wire [0:0] axis_block_sigs;
wire [5:0] inst_idle_sigs;
wire [2:0] inst_block_sigs;
wire kernel_block;

assign axis_block_sigs[0] = ~Loop_outer_loop_for_rx_1_proc1_U0.grp_Loop_outer_loop_for_rx_1_proc1_Pipeline_outer_loop_for_rx_1_inner_loop_for_rx_1_fu_86.axi_stream_in_TDATA_blk_n;

assign inst_idle_sigs[0] = entry_proc_U0.ap_idle;
assign inst_block_sigs[0] = (entry_proc_U0.ap_done & ~entry_proc_U0.ap_continue) | ~entry_proc_U0.axi_burst_out_c_blk_n;
assign inst_idle_sigs[1] = Loop_outer_loop_for_rx_1_proc1_U0.ap_idle;
assign inst_block_sigs[1] = (Loop_outer_loop_for_rx_1_proc1_U0.ap_done & ~Loop_outer_loop_for_rx_1_proc1_U0.ap_continue) | ~Loop_outer_loop_for_rx_1_proc1_U0.grp_Loop_outer_loop_for_rx_1_proc1_Pipeline_outer_loop_for_rx_1_inner_loop_for_rx_1_fu_86.stream_rx_array_V_blk_n | ~Loop_outer_loop_for_rx_1_proc1_U0.length_r_c_blk_n | ~Loop_outer_loop_for_rx_1_proc1_U0.width_c_blk_n;
assign inst_idle_sigs[2] = Loop_outer_loop_for_rx_2_proc2_U0.ap_idle;
assign inst_block_sigs[2] = (Loop_outer_loop_for_rx_2_proc2_U0.ap_done & ~Loop_outer_loop_for_rx_2_proc2_U0.ap_continue) | ~Loop_outer_loop_for_rx_2_proc2_U0.width_blk_n | ~Loop_outer_loop_for_rx_2_proc2_U0.length_r_blk_n | ~Loop_outer_loop_for_rx_2_proc2_U0.axi_burst_out_blk_n | ~Loop_outer_loop_for_rx_2_proc2_U0.grp_Loop_outer_loop_for_rx_2_proc2_Pipeline_inner_loop_for_rx_2_fu_66.stream_rx_array_V_blk_n;

assign inst_idle_sigs[3] = 1'b0;
assign inst_idle_sigs[4] = Loop_outer_loop_for_rx_1_proc1_U0.ap_idle;
assign inst_idle_sigs[5] = Loop_outer_loop_for_rx_1_proc1_U0.grp_Loop_outer_loop_for_rx_1_proc1_Pipeline_outer_loop_for_rx_1_inner_loop_for_rx_1_fu_86.ap_idle;

AXIDMA_RX_hls_deadlock_idx0_monitor AXIDMA_RX_hls_deadlock_idx0_monitor_U (
    .clock(kernel_monitor_clock),
    .reset(kernel_monitor_reset),
    .axis_block_sigs(axis_block_sigs),
    .inst_idle_sigs(inst_idle_sigs),
    .inst_block_sigs(inst_block_sigs),
    .block(kernel_block)
);


always @ (kernel_block or kernel_monitor_reset) begin
    if (kernel_block == 1'b1 && kernel_monitor_reset == 1'b0) begin
        find_kernel_block = 1'b1;
    end
    else begin
        find_kernel_block = 1'b0;
    end
end
