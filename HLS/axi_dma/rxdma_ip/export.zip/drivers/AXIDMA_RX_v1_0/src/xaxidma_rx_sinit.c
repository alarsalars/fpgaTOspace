// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2022.2 (64-bit)
// Tool Version Limit: 2019.12
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#include "xparameters.h"
#include "xaxidma_rx.h"

extern XAxidma_rx_Config XAxidma_rx_ConfigTable[];

XAxidma_rx_Config *XAxidma_rx_LookupConfig(u16 DeviceId) {
	XAxidma_rx_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XAXIDMA_RX_NUM_INSTANCES; Index++) {
		if (XAxidma_rx_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XAxidma_rx_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XAxidma_rx_Initialize(XAxidma_rx *InstancePtr, u16 DeviceId) {
	XAxidma_rx_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XAxidma_rx_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XAxidma_rx_CfgInitialize(InstancePtr, ConfigPtr);
}

#endif

