// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2022.2 (64-bit)
// Tool Version Limit: 2019.12
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// ==============================================================
/***************************** Include Files *********************************/
#include "xaxidma_tx.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XAxidma_tx_CfgInitialize(XAxidma_tx *InstancePtr, XAxidma_tx_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Control_BaseAddress = ConfigPtr->Control_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XAxidma_tx_Start(XAxidma_tx *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XAxidma_tx_ReadReg(InstancePtr->Control_BaseAddress, XAXIDMA_TX_CONTROL_ADDR_AP_CTRL) & 0x80;
    XAxidma_tx_WriteReg(InstancePtr->Control_BaseAddress, XAXIDMA_TX_CONTROL_ADDR_AP_CTRL, Data | 0x01);
}

u32 XAxidma_tx_IsDone(XAxidma_tx *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XAxidma_tx_ReadReg(InstancePtr->Control_BaseAddress, XAXIDMA_TX_CONTROL_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XAxidma_tx_IsIdle(XAxidma_tx *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XAxidma_tx_ReadReg(InstancePtr->Control_BaseAddress, XAXIDMA_TX_CONTROL_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XAxidma_tx_IsReady(XAxidma_tx *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XAxidma_tx_ReadReg(InstancePtr->Control_BaseAddress, XAXIDMA_TX_CONTROL_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XAxidma_tx_EnableAutoRestart(XAxidma_tx *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XAxidma_tx_WriteReg(InstancePtr->Control_BaseAddress, XAXIDMA_TX_CONTROL_ADDR_AP_CTRL, 0x80);
}

void XAxidma_tx_DisableAutoRestart(XAxidma_tx *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XAxidma_tx_WriteReg(InstancePtr->Control_BaseAddress, XAXIDMA_TX_CONTROL_ADDR_AP_CTRL, 0);
}

void XAxidma_tx_Set_axi_sb(XAxidma_tx *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XAxidma_tx_WriteReg(InstancePtr->Control_BaseAddress, XAXIDMA_TX_CONTROL_ADDR_AXI_SB_DATA, (u32)(Data));
    XAxidma_tx_WriteReg(InstancePtr->Control_BaseAddress, XAXIDMA_TX_CONTROL_ADDR_AXI_SB_DATA + 4, (u32)(Data >> 32));
}

u64 XAxidma_tx_Get_axi_sb(XAxidma_tx *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XAxidma_tx_ReadReg(InstancePtr->Control_BaseAddress, XAXIDMA_TX_CONTROL_ADDR_AXI_SB_DATA);
    Data += (u64)XAxidma_tx_ReadReg(InstancePtr->Control_BaseAddress, XAXIDMA_TX_CONTROL_ADDR_AXI_SB_DATA + 4) << 32;
    return Data;
}

void XAxidma_tx_Set_length_r(XAxidma_tx *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XAxidma_tx_WriteReg(InstancePtr->Control_BaseAddress, XAXIDMA_TX_CONTROL_ADDR_LENGTH_R_DATA, Data);
}

u32 XAxidma_tx_Get_length_r(XAxidma_tx *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XAxidma_tx_ReadReg(InstancePtr->Control_BaseAddress, XAXIDMA_TX_CONTROL_ADDR_LENGTH_R_DATA);
    return Data;
}

void XAxidma_tx_Set_width(XAxidma_tx *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XAxidma_tx_WriteReg(InstancePtr->Control_BaseAddress, XAXIDMA_TX_CONTROL_ADDR_WIDTH_DATA, Data);
}

u32 XAxidma_tx_Get_width(XAxidma_tx *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XAxidma_tx_ReadReg(InstancePtr->Control_BaseAddress, XAXIDMA_TX_CONTROL_ADDR_WIDTH_DATA);
    return Data;
}

void XAxidma_tx_InterruptGlobalEnable(XAxidma_tx *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XAxidma_tx_WriteReg(InstancePtr->Control_BaseAddress, XAXIDMA_TX_CONTROL_ADDR_GIE, 1);
}

void XAxidma_tx_InterruptGlobalDisable(XAxidma_tx *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XAxidma_tx_WriteReg(InstancePtr->Control_BaseAddress, XAXIDMA_TX_CONTROL_ADDR_GIE, 0);
}

void XAxidma_tx_InterruptEnable(XAxidma_tx *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XAxidma_tx_ReadReg(InstancePtr->Control_BaseAddress, XAXIDMA_TX_CONTROL_ADDR_IER);
    XAxidma_tx_WriteReg(InstancePtr->Control_BaseAddress, XAXIDMA_TX_CONTROL_ADDR_IER, Register | Mask);
}

void XAxidma_tx_InterruptDisable(XAxidma_tx *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XAxidma_tx_ReadReg(InstancePtr->Control_BaseAddress, XAXIDMA_TX_CONTROL_ADDR_IER);
    XAxidma_tx_WriteReg(InstancePtr->Control_BaseAddress, XAXIDMA_TX_CONTROL_ADDR_IER, Register & (~Mask));
}

void XAxidma_tx_InterruptClear(XAxidma_tx *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XAxidma_tx_WriteReg(InstancePtr->Control_BaseAddress, XAXIDMA_TX_CONTROL_ADDR_ISR, Mask);
}

u32 XAxidma_tx_InterruptGetEnabled(XAxidma_tx *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XAxidma_tx_ReadReg(InstancePtr->Control_BaseAddress, XAXIDMA_TX_CONTROL_ADDR_IER);
}

u32 XAxidma_tx_InterruptGetStatus(XAxidma_tx *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XAxidma_tx_ReadReg(InstancePtr->Control_BaseAddress, XAXIDMA_TX_CONTROL_ADDR_ISR);
}

