// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2022.2 (64-bit)
// Tool Version Limit: 2019.12
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#include "xparameters.h"
#include "xaxidma_tx.h"

extern XAxidma_tx_Config XAxidma_tx_ConfigTable[];

XAxidma_tx_Config *XAxidma_tx_LookupConfig(u16 DeviceId) {
	XAxidma_tx_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XAXIDMA_TX_NUM_INSTANCES; Index++) {
		if (XAxidma_tx_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XAxidma_tx_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XAxidma_tx_Initialize(XAxidma_tx *InstancePtr, u16 DeviceId) {
	XAxidma_tx_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XAxidma_tx_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XAxidma_tx_CfgInitialize(InstancePtr, ConfigPtr);
}

#endif

