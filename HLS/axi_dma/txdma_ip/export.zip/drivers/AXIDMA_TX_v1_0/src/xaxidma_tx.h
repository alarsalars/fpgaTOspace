// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2022.2 (64-bit)
// Tool Version Limit: 2019.12
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef XAXIDMA_TX_H
#define XAXIDMA_TX_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xaxidma_tx_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
#else
typedef struct {
    u16 DeviceId;
    u64 Control_BaseAddress;
} XAxidma_tx_Config;
#endif

typedef struct {
    u64 Control_BaseAddress;
    u32 IsReady;
} XAxidma_tx;

typedef u32 word_type;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XAxidma_tx_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XAxidma_tx_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XAxidma_tx_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XAxidma_tx_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
int XAxidma_tx_Initialize(XAxidma_tx *InstancePtr, u16 DeviceId);
XAxidma_tx_Config* XAxidma_tx_LookupConfig(u16 DeviceId);
int XAxidma_tx_CfgInitialize(XAxidma_tx *InstancePtr, XAxidma_tx_Config *ConfigPtr);
#else
int XAxidma_tx_Initialize(XAxidma_tx *InstancePtr, const char* InstanceName);
int XAxidma_tx_Release(XAxidma_tx *InstancePtr);
#endif

void XAxidma_tx_Start(XAxidma_tx *InstancePtr);
u32 XAxidma_tx_IsDone(XAxidma_tx *InstancePtr);
u32 XAxidma_tx_IsIdle(XAxidma_tx *InstancePtr);
u32 XAxidma_tx_IsReady(XAxidma_tx *InstancePtr);
void XAxidma_tx_EnableAutoRestart(XAxidma_tx *InstancePtr);
void XAxidma_tx_DisableAutoRestart(XAxidma_tx *InstancePtr);

void XAxidma_tx_Set_axi_sb(XAxidma_tx *InstancePtr, u64 Data);
u64 XAxidma_tx_Get_axi_sb(XAxidma_tx *InstancePtr);
void XAxidma_tx_Set_length_r(XAxidma_tx *InstancePtr, u32 Data);
u32 XAxidma_tx_Get_length_r(XAxidma_tx *InstancePtr);
void XAxidma_tx_Set_width(XAxidma_tx *InstancePtr, u32 Data);
u32 XAxidma_tx_Get_width(XAxidma_tx *InstancePtr);

void XAxidma_tx_InterruptGlobalEnable(XAxidma_tx *InstancePtr);
void XAxidma_tx_InterruptGlobalDisable(XAxidma_tx *InstancePtr);
void XAxidma_tx_InterruptEnable(XAxidma_tx *InstancePtr, u32 Mask);
void XAxidma_tx_InterruptDisable(XAxidma_tx *InstancePtr, u32 Mask);
void XAxidma_tx_InterruptClear(XAxidma_tx *InstancePtr, u32 Mask);
u32 XAxidma_tx_InterruptGetEnabled(XAxidma_tx *InstancePtr);
u32 XAxidma_tx_InterruptGetStatus(XAxidma_tx *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
